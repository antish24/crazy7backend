view apidoc file to get doc how to use the api
